# alghw1
# Implement linked list together
# Split graph and stack implementation